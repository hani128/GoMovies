﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class _Default : System.Web.UI.Page
{
    SqlConnection T = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\h.mdf;Integrated Security=True");
    protected void Page_Load(object sender, EventArgs e)
    {
        if (T.State == ConnectionState.Open)
            T.Close();
        T.Open();
       
        
    }

   
    protected void name_TextChanged(object sender, EventArgs e)
    {
        
    }

    protected void Button1_Click1(object sender, EventArgs e)
    {
        SqlCommand send = T.CreateCommand();
        send.CommandType = CommandType.Text;
        send.CommandText = "INSERT INTO Amovies values('" + nameM.Text +"','"+imgM.FileName+"','"+year.Text+"','"+language.Text+"','"+country.Text+"','"+type.Text+"','"+rate.Text+"','"+category.Text+"','"+quality.Text+"','"+ActorName.Text+"')";
        send.ExecuteNonQuery();
        
        GridView1.DataBind();
        
       
                
    }


    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        SqlCommand send = T.CreateCommand();
        send.CommandType = CommandType.Text;
        send.CommandText = "INSERT INTO Actors values('" + nameA.Text + "','" + imgA.FileName +  "')";
        send.ExecuteNonQuery();
        GridView2.DataBind();
        d();
        
    }
    public void d()
    {
        SqlCommand cmd = T.CreateCommand();
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = "SELECT name FROM Actors";
        cmd.ExecuteNonQuery();
        DataSet ds = new DataSet();
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(ds);
        for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
        {
            ActorName.Items.Add(ds.Tables[0].Rows[i][0].ToString());
        }
        ActorName.DataBind();

    }

    protected void type_SelectedIndexChanged(object sender, EventArgs e)
    {

    }


    protected void GridView1_SelectedIndexChanged1(object sender, EventArgs e)
    {

    }


    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    protected void ListBox1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}