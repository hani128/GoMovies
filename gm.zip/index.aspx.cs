﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class search : System.Web.UI.Page
{
    SqlConnection T = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\h.mdf;Integrated Security=True");
    protected void Page_Load(object sender, EventArgs e)
    {
        if (T.State == ConnectionState.Open)
            T.Close();
        T.Open();
    }

    protected void Button1_Click(object sender, EventArgs e)
    {

        string serAct = "SELECT * FROM Amovies WHERE ActName like '%" + SearchAct.Text + "%' OR name like '%" + SearchAct.Text + "%'";
        SqlDataSource1.SelectCommand = serAct;
        FormView1.DataBind();
        

    }



 
    protected void GridView2_SelectedIndexChanged(object sender, EventArgs e)
    {

    }





}