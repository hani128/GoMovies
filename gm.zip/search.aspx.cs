﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class search : System.Web.UI.Page
{
    SqlConnection T = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\h.mdf;Integrated Security=True");
    protected void Page_Load(object sender, EventArgs e)
    {
        if (T.State == ConnectionState.Open)
            T.Close();
        T.Open();
        FormView2.Visible = false;
        Backbtn.Visible = false;
        GridView2.Visible = false;
    }

    protected void Button1_Click(object sender, EventArgs e)
    {

        string serAct = "SELECT * FROM Amovies WHERE ActName like '%" + SearchAct.Text + "%' OR name like '%" + SearchAct.Text + "%'";
        SqlDataSource1.SelectCommand = serAct;
        FormView1.DataBind();


    }




    protected void GridView2_SelectedIndexChanged(object sender, EventArgs e)
    {

    }



    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        string ser1 = "SELECT * FROM Actors WHERE name = '" + GridView1.SelectedRow.Cells[11].Text + "' ";
        SqlDataSource3.SelectCommand = ser1;
        FormView2.DataBind();
        string ser2 = "SELECT name,img,ActName FROM Amovies WHERE ActName = '" + GridView1.SelectedRow.Cells[11].Text + "' ";
        SqlDataSource4.SelectCommand = ser2;
        GridView2.DataBind();

        GridView1.Visible = false;
        FormView2.Visible = true;
        Backbtn.Visible = true;
        GridView2.Visible = true;
    }



    protected void Button2_Click(object sender, EventArgs e)
    {
        GridView1.Visible = true;
        FormView2.Visible = false;
        Backbtn.Visible = false;
        GridView2.Visible = false;
    }
}