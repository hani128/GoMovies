﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class login : System.Web.UI.Page
{
    SqlConnection T = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\h.mdf;Integrated Security=True");
    protected void Page_Load(object sender, EventArgs e)
    {
        if (T.State == ConnectionState.Open)
            T.Close();
        T.Open();
    }

    protected void check_Click(object sender, EventArgs e)
    {
        SqlCommand send = T.CreateCommand();
        send.CommandType = CommandType.Text;
        send.CommandText = "SELECT * FROM login WHERE username='"+un.Text+"'AND pass='"+pw.Text+"'";
        send.ExecuteNonQuery();
        DataSet s = new DataSet();
        SqlDataAdapter c = new SqlDataAdapter(send);
        c.Fill(s);
        if (s.Tables[0].Rows.Count > 0)
        {
            Response.Redirect("admin.aspx");
        }
        else
        {
            error.Visible = true;
            error.Text = "wrong username or password";
        }
        

        
    }
}